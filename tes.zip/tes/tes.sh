#!/usr/bin/sh

clear
figlet SINYAL

echo ""
echo "1. run"
echo "2. back awal"

read -p "pilih (1/2): " pil
if [ $pil = "1" ]
then
  ifconfig
echo "silahkan ketik ping -s 9000 masukan ip"
elif [ $pil = "2" ] 
then
  bash pemula2.sh
fi



