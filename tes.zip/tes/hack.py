#!/bin/python
import os,sys,time

def bersih():
     os.system("clear")

def menu():
    bersih()
    print "========================="
    os.system("figlet Hack")
    print "Nama: Hafidz"
    print "Author: jarvis"
    print "========================="
    print "[1].Seeker"
    print "[2].back awal"
    pil = raw_input("pilih: ")
    if pil =="1":
       os.system("pkg install python3")
       bersih()
       os.system("python3 seeker.py")
    elif pil =="2":
       os.system("bash pemula2.sh")
menu()
